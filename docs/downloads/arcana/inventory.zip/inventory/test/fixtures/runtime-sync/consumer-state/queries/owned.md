# Consumer Query
