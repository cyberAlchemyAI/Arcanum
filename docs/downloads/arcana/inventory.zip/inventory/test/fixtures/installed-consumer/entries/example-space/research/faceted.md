---
id: faceted
---

# Faceted
